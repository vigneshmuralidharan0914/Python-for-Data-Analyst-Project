feedback_data = {
    'S_No': [1,2,3,4,5,6,7,8,9,10],
    'Name': ['Ravi','Meera','Sam','Anu','Raj','Divya','Arjun','Kiran','Leela','Nisha'],
    'Feedback': [
        ' Very GOOD Service!!!',
        'poor support, not happy ',
        'GREAT experience! will come again.',
        'okay okay...',
        ' not BAD',
        'Excellent care, excellent staff!',
        'good food and good ambience!',
        'Poor response and poor handling of issue',
        'Satisfied. But could be better.',
        'Good support... quick service.'
    ],
    'Rating': [5,2,5,3,2,5,4,1,3,4]
}

print("=" * 50)
print("SURVEY FEEDBACK ANALYZER")
print("=" * 50)

n = int(input("How many more feedbacks do you want to add? "))

for i in range(n):
    s_no = len(feedback_data['S_No']) + 1
    name = input("Enter Name: ")
    feedback = input("Enter Feedback: ")

    while True:
        rating = int(input("Enter Rating (1-5): "))
        if 1 <= rating <= 5:
            break
        print("Rating must be between 1 and 5.")

    feedback_data['S_No'].append(s_no)
    feedback_data['Name'].append(name)
    feedback_data['Feedback'].append(feedback)
    feedback_data['Rating'].append(rating)


def clean_feedback(text):
    text = text.lower()
    text = text.replace(".", "")
    text = text.replace(",", "")
    text = text.replace("!", "")
    text = text.replace("?", "")
    text = " ".join(text.split())
    return text


for i in range(len(feedback_data['Feedback'])):
    feedback_data['Feedback'][i] = clean_feedback(
        feedback_data['Feedback'][i]
    )


def count_word_in_feedbacks(word):
    count = 0
    word = word.lower()

    for feedback in feedback_data['Feedback']:
        if word in feedback.split():
            count += 1

    return count


good_count = count_word_in_feedbacks("good")
poor_count = count_word_in_feedbacks("poor")
excellent_count = count_word_in_feedbacks("excellent")


print("\n" + "=" * 50)
print("FINAL CLEANED DATA")
print("=" * 50)
print(feedback_data)


average_rating = sum(feedback_data['Rating']) / len(feedback_data['Rating'])
print("\nAverage Rating:", round(average_rating, 2))


longest_feedback = ""
longest_word_count = 0

for feedback in feedback_data['Feedback']:
    word_count = len(feedback.split())

    if word_count > longest_word_count:
        longest_word_count = word_count
        longest_feedback = feedback

print("\nLongest Feedback:")
print(longest_feedback)
print("Word Count:", longest_word_count)


unique_words = set()

for feedback in feedback_data['Feedback']:
    for word in feedback.split():
        unique_words.add(word)

print("\nUnique Words:")
print(sorted(unique_words))


print("\n" + "=" * 50)
print("WORD COUNT INSIGHTS")
print("=" * 50)

print("Good:", good_count)
print("Poor:", poor_count)
print("Excellent:", excellent_count)


sorted_feedbacks = sorted(
    zip(
        feedback_data['S_No'],
        feedback_data['Name'],
        feedback_data['Feedback'],
        feedback_data['Rating']
    ),
    key=lambda x: x[3],
    reverse=True
)

print("\n" + "=" * 50)
print("FEEDBACKS SORTED BY RATING")
print("=" * 50)

for item in sorted_feedbacks:
    print(
        "S.No:", item[0],
        "| Name:", item[1],
        "| Feedback:", item[2],
        "| Rating:", item[3]
    )

print("\n" + "=" * 50)
print("ANALYSIS COMPLETED SUCCESSFULLY")
print("=" * 50)