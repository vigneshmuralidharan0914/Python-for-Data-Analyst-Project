"""
Python DA Assignment 1: Data Analysis using NumPy and Pandas
Full Solution
"""

import numpy as np
import pandas as pd

print("=" * 60)
print("PART 1: NUMPY ARRAY OPERATIONS")
print("=" * 60)

# 1. Create a 1D NumPy Array
temperatures_w1 = np.array([22.5, 25.3, 20.8, 23.4, 26.1, 24.8, 21.9])
print("\n1. Week 1 Temperatures Array:")
print(temperatures_w1)

# 2. Inspection and Properties
print("\n2. Inspection and Properties:")
print("Shape:", temperatures_w1.shape)
print("Data type:", temperatures_w1.dtype)
print("Number of elements:", temperatures_w1.size)

# 3. Array Operations
print("\n3. Array Operations:")
temperatures_w1_fahrenheit = (temperatures_w1 * 9 / 5) + 32
print("Temperatures in Fahrenheit:", temperatures_w1_fahrenheit)

print("Maximum temperature:", temperatures_w1.max())
print("Minimum temperature:", temperatures_w1.min())
print("Mean temperature:", temperatures_w1.mean())

# 4. Array Slicing and Indexing
print("\n4. Array Slicing and Indexing:")
first_three_days = temperatures_w1[0:3]
print("First three days:", first_three_days)

weekend = temperatures_w1[-2:]
print("Weekend (last two days):", weekend)

middle_three_days = temperatures_w1[2:5]
print("Middle three days:", middle_three_days)

# 5. Create a 2D Array
temperatures = np.array([
    [22.5, 25.3, 20.8, 23.4, 26.1, 24.8, 21.9],  # Week 1
    [19.2, 22.5, 21.3, 24.0, 23.5, 22.8, 20.1]   # Week 2
])
print("\n5. 2D Temperatures Array:")
print(temperatures)

# 6. Inspect and Slice the 2D Array
print("\n6. Inspect and Slice the 2D Array:")
print("Shape:", temperatures.shape)
print("Data type:", temperatures.dtype)
print("Total number of elements:", temperatures.size)

week1 = temperatures[0]
week2 = temperatures[1]
print("Week 1 temperatures:", week1)
print("Week 2 temperatures:", week2)

week1_weekend = temperatures[0, -2:]
week2_weekend = temperatures[1, -2:]
print("Week 1 weekend:", week1_weekend)
print("Week 2 weekend:", week2_weekend)


print("\n" + "=" * 60)
print("PART 2: PANDAS SERIES")
print("=" * 60)

# 1. Creating Pandas Series
marks = pd.Series([95, 92, 89, 85, 80],
                   index=['Rank1', 'Rank2', 'Rank3', 'Rank4', 'Rank5'])
print("\n1. Marks Series:")
print(marks)

# 2. Indexing and Slicing
print("\n2. Indexing and Slicing:")
print("1st rank mark (integer position):", marks.iloc[0])
print("Top 3 ranks (loc):")
print(marks.loc[['Rank1', 'Rank2', 'Rank3']])
print("3rd rank mark (iloc):", marks.iloc[2])
print("Ranks with marks > 90 (boolean mask):")
print(marks[marks > 90])

# 3. Manipulating Series
print("\n3. Manipulating Series:")
marks['Rank1'] = 100
print("After modifying Rank1 to 100:")
print(marks)

marks = marks.drop('Rank5')
print("\nAfter removing last rank (Rank5):")
print(marks)

cgpa = marks / 10
print("\nCGPA (marks / 10):")
print(cgpa)


print("\n" + "=" * 60)
print("PART 3: PANDAS DATAFRAME")
print("=" * 60)

# 1. Creating Pandas DataFrame
transactions = pd.DataFrame({
    'TransactionID': [101, 102, 103, 104, 105, 106, 107, 108, 109, 110],
    'ProductCategory': ['Electronics', 'Clothing', 'Electronics', 'Furniture',
                         'Clothing', 'Electronics', 'Furniture', 'Clothing',
                         'Furniture', 'Electronics'],
    'Region': ['North', 'South', 'North', 'East', 'West',
               'North', 'East', 'West', 'South', 'North'],
    'Amount': [200, 150, 300, 450, 200, 250, 300, 180, 350, 400]
})
print("\n1. Transactions DataFrame:")
print(transactions)

# 2. Data Exploration
print("\n2. Data Exploration:")
print("\nHead:")
print(transactions.head())
print("\nTail:")
print(transactions.tail())
print("\nShape:", transactions.shape)
print("Column names:", list(transactions.columns))
print("\nData types:")
print(transactions.dtypes)
print("\nInfo:")
transactions.info()

print("\nProductCategory and Amount columns:")
print(transactions[['ProductCategory', 'Amount']])

print("\nLast 3 columns (iloc):")
print(transactions.iloc[:, -3:])

print("\nRows where Region is North and Amount > 200:")
print(transactions[(transactions['Region'] == 'North') & (transactions['Amount'] > 200)])

print("\nValue counts for ProductCategory:")
print(transactions['ProductCategory'].value_counts())

print("\nUnique values in Region:")
print(transactions['Region'].unique())

print("\nMean Amount grouped by Region:")
print(transactions.groupby('Region')['Amount'].mean())

# 3. Manipulating the DataFrame
print("\n3. Manipulating the DataFrame:")
transactions.loc[transactions['TransactionID'] == 102, 'Amount'] = 165
print("\nAfter modifying Amount for TransactionID 102 to 165:")
print(transactions)

transactions['Discount'] = transactions['Amount'] * 0.10
print("\nAfter adding Discount column (10% of Amount):")
print(transactions)

transactions = transactions[transactions['TransactionID'] != 109]
print("\nAfter removing row with TransactionID 109:")
print(transactions)

transactions = transactions.drop(columns=['Discount'])
print("\nAfter deleting Discount column:")
print(transactions)