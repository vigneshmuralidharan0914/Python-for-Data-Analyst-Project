# ==========================================
# PYTHON ASSIGNMENT 2
# Data Structures - List, Dictionary, Set
# & Conditional Statements
# ==========================================


# ==========================================
# 1. LIST - CREATION
# ==========================================

age_list = [24, 25, 26, 27, 28]

name_list = ["Vignesh", "Arun", "Priya", "Kumar", "Divya"]

print("========== LIST CREATION ==========")
print("Age List:", age_list)
print("Name List:", name_list)


# ==========================================
# 2. LIST OPERATIONS / MODIFICATIONS
# ==========================================

print("\n========== LIST OPERATIONS ==========")

# a. Append Yazhini
name_list.append("Yazhini")
print("After append:", name_list)


# b. Insert 30 at index 2
age_list.insert(2, 30)
print("After insert:", age_list)


# c. Remove Yazhini
name_list.remove("Yazhini")
print("After remove:", name_list)


# d. Pop last element
age_list.pop()
print("After pop:", age_list)


# e. Extend age_list
age_list.extend([29, 30, 26])
print("After extend:", age_list)


# f. Sort age_list in descending order
age_list.sort(reverse=True)
print("Descending order:", age_list)


# g. Maximum, Minimum and Sum
max_age = max(age_list)
min_age = min(age_list)
total_age = sum(age_list)

print("Maximum age:", max_age)
print("Minimum age:", min_age)
print("Sum of all ages:", total_age)


# ==========================================
# 3. ACCESSING LIST ELEMENTS
# ==========================================

print("\n========== ACCESSING LIST ELEMENTS ==========")

# a. First element
print("First element:", name_list[0])

# b. Last element
print("Last element:", name_list[-1])

# c. Elements from index 2 to 4
print("Elements from index 2 to 4:", name_list[2:5])

# d. Reverse order
print("Reverse order:", name_list[::-1])


# ==========================================
# 4. DICTIONARY - CREATION
# ==========================================

student_marks = {
    "Vignesh": 75,
    "Arun": 82,
    "Priya": 90,
    "Kumar": 68,
    "Divya": 88
}

print("\n========== DICTIONARY ==========")

print("Original student marks:")
print(student_marks)


# b. Access specific student's mark
print("Priya's mark:", student_marks["Priya"])


# c. Add Janani
student_marks["Janani"] = 80
print("After adding Janani:")
print(student_marks)


# d. Update older student's mark
student_marks["Vignesh"] = 82
print("After updating Vignesh's mark:")
print(student_marks)


# e. Keys
print("Keys:", student_marks.keys())


# Values
print("Values:", student_marks.values())


# Items
print("Items:", student_marks.items())


# ==========================================
# 5. SET - CREATION
# ==========================================

print("\n========== SET ==========")

my_set = {'a', 'e', 'i', 'o', 'u', 'a', 'a', 'i'}

print("My Set:", my_set)

print("\nExplanation:")
print("A set stores only unique elements.")
print("Duplicate values are automatically removed.")
print("Therefore, a and i appear only once.")


# ==========================================
# 6. TRY TO CHANGE SET VALUE
# ==========================================

print("\n========== SET VALUE CHANGE ==========")

try:
    my_set[4] = 's'

except TypeError as error:
    print("Error:", error)
    print("Explanation: Set does not support indexing or item assignment.")


# ==========================================
# 7. UNION AND INTERSECTION
# ==========================================

print("\n========== UNION AND INTERSECTION ==========")

set1 = {1, 3, 5, 7, 9}

set2 = {2, 3, 5, 8, 10}

print("Set 1:", set1)
print("Set 2:", set2)


# Union
union_set = set1.union(set2)
print("Union:", union_set)


# Intersection
intersection_set = set1.intersection(set2)
print("Intersection:", intersection_set)


# ==========================================
# 8. IF, ELIF, ELSE
# PERFORMANCE CATEGORY PROGRAM
# ==========================================

print("\n========== PERFORMANCE CATEGORY ==========")

score = float(input("Enter your score (0 to 10): "))


if score < 0 or score > 10:

    print("Invalid score! Please enter a score between 0 and 10.")


elif score > 7:

    print("Above Average: Excellent performance! Keep up the good work.")


elif score >= 4:

    print("Average: Good effort! Keep practicing, there's room for improvement.")


else:

    print("Below Average: Need to improve your performance. Consistent practice will lead to better results.")