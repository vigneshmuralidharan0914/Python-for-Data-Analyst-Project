str1 = "Hello "
str2 = input("Enter your Name: ")
concat_str = str1 + str2
print(concat_str)

str3 = ", welcome to Python programming"
concat_str = concat_str + str3
print(concat_str)




s = "Hello Zara, welcome to Python programming"

print(s[0])       # a. first character
print(s[-1])      # b. last character
print(s[:5])      # c. first 5 characters
print(s[-11:])    # d. last 11 characters
print(s[::-1])    # e. reverse
print(s[23:29])   # f. word "Python"






strM = "Python beginner tutorial"

strM = "Python beginner tutorial"

print(strM.upper())        # a
print(strM.lower())        # b
print(strM.capitalize())   # c
print(strM.count('t'))     # d
print(strM.replace("Python", "Machine Learning"))  # e






tuple1 = (10, 20, 30)
tuple2 = (40, 50, 60)

t_combine = tuple1 + tuple2      # a
print(t_combine)

t_repeat = t_combine * 3         # b
print(t_repeat)

print(t_combine[2])              # c
print(t_combine[:3])             # d
print(t_combine[-3:])            # e