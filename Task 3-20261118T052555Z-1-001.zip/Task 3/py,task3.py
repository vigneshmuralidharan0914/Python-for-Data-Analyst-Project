# ==========================================
# PYTHON ASSIGNMENT 3
# While Loop, For Loop and Function
# ==========================================


# 1. WHILE LOOP - NUMBER GUESSING GAME

import random

secret_number = random.randint(1, 10)
attempts = 3

while attempts > 0:

    guess = int(input("Guess the number (between 1 and 10): "))

    if guess < 1 or guess > 10:
        print("Your guess is out of range. Please guess a number between 1 and 10.")
        continue

    attempts -= 1

    if guess < secret_number:
        print("Too low. Try again.")

    elif guess > secret_number:
        print("Too high. Try again.")

    else:
        print("Congratulations! You guessed the correct number.")
        break

else:
    print("Better luck next time!")


# ==========================================
# 2. FOR LOOP - MULTIPLICATION TABLE
# ==========================================

number = int(input("\nEnter the number for which you want the multiplication table: "))

for i in range(1, 11):

    result = number * i

    print(number, "x", i, "=", result)


# ==========================================
# 3. FUNCTION - BMI CALCULATOR
# ==========================================

def calculate_bmi(weight, height):

    bmi = weight / (height ** 2)

    return bmi


weight = float(input("\nEnter your weight in kg: "))

height = float(input("Enter your height in meters: "))

bmi = calculate_bmi(weight, height)

print("Your BMI is:", format(bmi, ".2f"))