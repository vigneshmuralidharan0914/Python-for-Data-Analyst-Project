# ============================================================
# PYTHON DA ASSIGNMENT 2 - DATA VISUALIZATION
# ============================================================

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ------------------------------------------------------------
# 1. LOAD DATASET
# ------------------------------------------------------------
df = sns.load_dataset("taxis")

print("First 5 Rows:")
print(df.head())

print("\nDataset Information:")
print(df.info())

print("\nDataset Shape:")
print(df.shape)

# ------------------------------------------------------------
# 2. CHECK MISSING VALUES
# ------------------------------------------------------------
print("\nMissing Values Before Cleaning:")
print(df.isnull().sum())

# ------------------------------------------------------------
# 3. HANDLE MISSING VALUES
# ------------------------------------------------------------
# Numerical columns -> Median
num_cols = df.select_dtypes(include=['int64', 'float64']).columns

for col in num_cols:
    df[col] = df[col].fillna(df[col].median())

# Categorical columns -> Mode
cat_cols = df.select_dtypes(include=['object', 'category']).columns

for col in cat_cols:
    if df[col].isnull().sum() > 0:
        df[col] = df[col].fillna(df[col].mode()[0])

print("\nMissing Values After Cleaning:")
print(df.isnull().sum())

# Convert pickup column to datetime
df['pickup'] = pd.to_datetime(df['pickup'])

# ============================================================
# 4. LINE CHART - FARE OVER TIME
# ============================================================
plt.figure(figsize=(12, 6))
plt.plot(df['pickup'], df['fare'])
plt.title('Fare Over Time')
plt.xlabel('Pickup Time')
plt.ylabel('Fare')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# ============================================================
# 5. BAR CHART - TOTAL FARE BY PICKUP BOROUGH
# ============================================================
borough_fare = df.groupby('pickup_borough')['fare'].sum()

plt.figure(figsize=(10, 6))
borough_fare.plot(kind='bar')
plt.title('Total Fare by Pickup Borough')
plt.xlabel('Pickup Borough')
plt.ylabel('Total Fare')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# ============================================================
# 6. PIE CHART - PAYMENT METHOD
# ============================================================
payment_counts = df['payment'].value_counts()

plt.figure(figsize=(8, 8))
plt.pie(
    payment_counts,
    labels=payment_counts.index,
    autopct='%1.1f%%',
    startangle=90
)
plt.title('Trip Distribution by Payment Method')
plt.show()

# ============================================================
# 7. HISTOGRAM - DISTANCE DISTRIBUTION
# ============================================================
plt.figure(figsize=(10, 6))
plt.hist(df['distance'], bins=20)
plt.title('Distribution of Trip Distance')
plt.xlabel('Distance')
plt.ylabel('Number of Trips')
plt.tight_layout()
plt.show()

# ============================================================
# 8. BOX PLOT - TIP BY PICKUP BOROUGH
# ============================================================
plt.figure(figsize=(10, 6))
sns.boxplot(data=df, x='pickup_borough', y='tip')
plt.title('Tip Distribution by Pickup Borough')
plt.xlabel('Pickup Borough')
plt.ylabel('Tip')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# ============================================================
# 9. COUNT PLOT - NUMBER OF TRIPS BY PICKUP BOROUGH
# ============================================================
plt.figure(figsize=(10, 6))
sns.countplot(data=df, x='pickup_borough')
plt.title('Number of Trips by Pickup Borough')
plt.xlabel('Pickup Borough')
plt.ylabel('Number of Trips')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# ============================================================
# 10. SCATTER PLOT - DISTANCE VS FARE
# ============================================================
plt.figure(figsize=(10, 6))
sns.scatterplot(
    data=df,
    x='distance',
    y='fare',
    hue='pickup_borough'
)
plt.title('Relationship Between Distance and Fare')
plt.xlabel('Distance')
plt.ylabel('Fare')
plt.tight_layout()
plt.show()

# ============================================================
# 11. HEATMAP - CORRELATION
# ============================================================
correlation = df[
    ['distance', 'fare', 'tip', 'tolls', 'total']
].corr()

plt.figure(figsize=(8, 6))
sns.heatmap(
    correlation,
    annot=True,
    fmt='.2f',
    cmap='coolwarm'
)
plt.title('Correlation Heatmap')
plt.tight_layout()
plt.show()

# ============================================================
# 12. PAIR PLOT
# ============================================================
sns.pairplot(
    df,
    vars=['distance', 'fare', 'tip', 'total'],
    hue='pickup_zone'
)
plt.show()

# ============================================================
# 13. VIOLIN PLOT - FARE BY PAYMENT METHOD
# ============================================================
plt.figure(figsize=(10, 6))
sns.violinplot(
    data=df,
    x='payment',
    y='fare'
)
plt.title('Fare Distribution by Payment Method')
plt.xlabel('Payment Method')
plt.ylabel('Fare')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# ============================================================
# 14. FINAL DATA CHECK
# ============================================================
print("\nFinal Dataset Shape:")
print(df.shape)

print("\nFinal Missing Values:")
print(df.isnull().sum())

print("\nAssignment Completed Successfully!")


python enterfinaltask.py